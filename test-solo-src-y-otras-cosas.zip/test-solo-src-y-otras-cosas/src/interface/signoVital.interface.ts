export interface ISignoVital{
    codigo:number
    descripcion:string
}
