const generarMensajeSatisfactorio=()=>{
        message:"Petición exitosa"
}

const generarMensajeError=()=>{
        message:"Error en la petición"
}

export {generarMensajeError,generarMensajeSatisfactorio}
